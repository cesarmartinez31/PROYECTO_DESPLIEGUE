import numpy as np
from config.core import config
from pipeline import modelo_agua_pipe  # Asegúrate de tener tu pipeline ya creado
from processing.data_manager import load_dataset, save_pipeline
from sklearn.model_selection import train_test_split

def run_training() -> None:
    """Train the models KMeans and Random Forest."""  

    # Leer los datos de entrenamiento
    data = load_dataset(file_name=config.app_config.train_data_file)

    # Dividir en conjunto de entrenamiento y prueba
    X_train, X_test, y_train, y_test = train_test_split(
        data[config.model_config.features_kmeans],  # Predictores de KMeans
        data[config.model_config.target],  # La variable objetivo
        test_size=config.model_config.test_size,
        random_state=config.model_config.random_state,
    )
    
    # Convertir la variable objetivo con el mapeo que definimos
    y_train = y_train.map(config.model_config.qual_mappings)

    # Entrenar el modelo de KMeans (suponiendo que es un pipeline)
    modelo_agua_pipe.fit(X_train, y_train)

    # Persistir el modelo entrenado
    save_pipeline(pipeline_to_persist=modelo_agua_pipe)


if __name__ == "__main__":
    run_training()
